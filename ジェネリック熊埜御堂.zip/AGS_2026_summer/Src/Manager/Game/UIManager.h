#pragma once
#include<memory>
#include<vector>
#include"../../Object/UI/UIName.h"

class UIBase;

class UIManager
{
public	:
	static void CreateInstance(void);
	static UIManager& GetInstance(void);
	static void DeleteInstance(void);
private:
	static UIManager* instance_;
	UIManager(void);
	UIManager(const UIManager& instance) = default;
	~UIManager(void) = default;
public:
	void Load(void);
	void Init(void);
	void Update(void);
	void Draw(void);
	void Clear(void);
	//�ŏ�ʂ�UI����ʂɒǉ�����֐�
	void AddRootUI(std::shared_ptr<UIBase> ui);

	template<typename T>
	std::shared_ptr<T> GetUI(UINAME name);

private:
	//��ʏ�ɑ��݂���UI�̃��[�g���Ǘ����郊�X�g
	std::vector<std::shared_ptr<UIBase>> rootUIList_;
};

template<typename T>
std::shared_ptr<T> UIManager::GetUI(UINAME name)
{
	for (auto& ui : rootUIList_)
	{
		if (ui->GetUIName() == name)
		{
			return std::dynamic_pointer_cast<T>(ui);
		}
	}
	return nullptr;
}
