#pragma once
//�Փˎ��
enum class CollisionPairType
{
	NONE = -1,

	SPHERE_SPHERE,
	SPHERE_CAPSULE,
	SPHERE_BOX,

	CAPSULE_CAPSULE,
	CAPSULE_BOX,

	BOX_BOX,

	SPHERE_MODEL,
	CAPSULE_MODEL,
	BOX_MODEL,
	MODEL_MODEL,
};