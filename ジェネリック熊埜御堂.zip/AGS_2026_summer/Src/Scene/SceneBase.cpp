#include "SceneBase.h"
#include"../Manager/Resource/ResourceManager.h"
#include"../Manager/Game/SceneManager.h"
#include"../Manager/Generic/KeyManager.h"
#include"../Application.h"

SceneBase::SceneBase(void) :
	resMng_(ResourceManager::GetInstance()),
	sceMng_(SceneManager::GetInstance())
{
}

SceneBase::~SceneBase(void)
{
}


// �ǂݍ���
void SceneBase::Load(void)
{
	SubLoad();
}

// ��������
void SceneBase::Init(void)
{
	SubInit();
	InitUI();
	InitSE();
}

// �X�V�X�e�b
void SceneBase::Update(void)
{
	if (SceneManager::GetInstance().GetSceneID() != SCENE_ID::PAUSE)
	{
		//�G�X�P�[�v�������烁�j���[�V�[����
		if (KeyManager::GetIns().GetInfo(KEY_TYPE::PAUSE).down)
		{
			SceneManager::GetInstance().PushScene(SCENE_ID::PAUSE);
			return;
		}
	}
	SubUpdate();
}

// �`�揈
void SceneBase::Draw(void)
{
	SubDraw();
}

// �����
void SceneBase::Release(void)
{
	SubRelease();
}
