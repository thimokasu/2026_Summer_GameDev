#include "GameMessageUI.h"
#include "../../../Manager/Game/SceneManager.h"

GameMessageUI::GameMessageUI(Vector2F pos, Vector2F size)
    : UIBase(pos, size)
    , fontHandle_(-1)
    , currentState_(MASSAGE_STATE::EXPLAIN)
    , animPhase_(ANIM_PHASE::FADE_IN)
    , animTime_(0.0f)
    , scaleX_(0.0f)
    , scaleY_(0.0f)
{
    type_ = UITYPE::TEXT; 
    textColor_ = GetColor(255, 255, 255);
    edgeColor_ = GetColor(0, 0, 0);
}

void GameMessageUI::SubLoad(void)
{
    if (fontHandle_ == -1)
    {
        fontHandle_ = CreateFontToHandle("Arial", FontSize, 6, DX_FONTTYPE_ANTIALIASING_EDGE, -1, EdgeSize);
    }
}

void GameMessageUI::SubInit(void)
{
    uiName_ = UINAME::FINDINGJ_MASSAGE;
    currentState_ = MASSAGE_STATE::EXPLAIN;
    animTime_ = 0.0f;
    scaleX_ = 0.0f;
    scaleY_ = 0.0f;
    animPhase_ = ANIM_PHASE::FADE_IN;
}

void GameMessageUI::SubUpdate(void)
{
    if (currentState_ != MASSAGE_STATE::NONE)
    {
        animTime_ += SceneManager::GetInstance().GetDeltaTime();
        TextAnim();
    }
    if (currentState_ == MASSAGE_STATE::START)
    {
        if (animPhase_ == ANIM_PHASE::FADE_OUT)
        {
            startCallBack_();
        }
    }
    if (currentState_ == MASSAGE_STATE::FINISH)
    {
        if (animPhase_ == ANIM_PHASE::FADE_OUT)
        {
            SceneManager::GetInstance().PushScene(SCENE_ID::PAUSE);
            SetMassageState(MASSAGE_STATE::NONE);
            animPhase_ = ANIM_PHASE::NONE;
        }
    }
}


void GameMessageUI::SubDraw(void)
{
    if (currentState_ == MASSAGE_STATE::NONE) return;

    const char* targetStr = nullptr;
    switch (currentState_)
    {
    case MASSAGE_STATE::EXPLAIN: targetStr = StrExplain; break;
    case MASSAGE_STATE::START:   targetStr = StrStart;   break;
    case MASSAGE_STATE::FINISH:  targetStr = StrFinish;  break;
    default: return;
    }
    if (targetStr == nullptr) return;

    int stringWidth = 0;
    int stringHeight = 0;
    GetDrawStringSizeToHandle(&stringWidth, &stringHeight, nullptr, targetStr, (int)strlen(targetStr), fontHandle_);

    float cx = stringWidth / 2.0f;
    float cy = stringHeight / 2.0f;

    // UIBase�����΍��W���擾
    Vector2F absPos = GetAbsolutePos();

    // UIBase��size_�̒��S��`��̊�_�i��ʒ����Ȃǁj�ɂ���
    int drawX = static_cast<int>(absPos.x + size_.x / 2.0f);
    int drawY = static_cast<int>(absPos.y + size_.y / 2.0f);

    // �Q�[�������̎����������̌��ɑт��o��
    if (currentState_ == MASSAGE_STATE::EXPLAIN)
    {
        int paddingY = 20;
        int barTop = drawY - (int)cy - paddingY;
        int barBottom = drawY + (int)cy + paddingY;

        SetDrawBlendMode(DX_BLENDMODE_ALPHA, 160);
        // �e����^����ꂽ�����isize_.x�j�����ς��ɑт�`��
        DrawBox(static_cast<int>(absPos.x), barTop, static_cast<int>(absPos.x + size_.x), barBottom, GetColor(0, 0, 0), TRUE);
        SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
    }

    DrawRotaStringToHandle(
        drawX, drawY,
        scaleX_, scaleY_,
        cx, cy,
        0.0,
        textColor_,
        fontHandle_,
        edgeColor_,
        FALSE,
        targetStr
    );
}

void GameMessageUI::SubRelease(void)
{
    if (fontHandle_ != -1)
    {
        DeleteFontToHandle(fontHandle_);
        fontHandle_ = -1;
    }
}

void GameMessageUI::SetMassageState(MASSAGE_STATE state)
{
    animTime_ = 0.0f;
    scaleX_ = 0.0f;
    scaleY_ = 0.0f;
    animPhase_ = ANIM_PHASE::FADE_IN;
    currentState_ = state;
    switch (state)
    {
    case GameMessageUI::MASSAGE_STATE::NONE:
        break;
    case GameMessageUI::MASSAGE_STATE::EXPLAIN:
        textColor_ = GetColor(255, 255, 255);
        edgeColor_ = GetColor(0, 0, 0);
        break;
    case GameMessageUI::MASSAGE_STATE::START:
        textColor_ = GetColor(0, 200, 255);
        edgeColor_ = GetColor(255, 255, 255);
        break;
    case GameMessageUI::MASSAGE_STATE::FINISH:
        textColor_ = GetColor(255, 215, 0);
        edgeColor_ = GetColor(255, 255, 255);
        break;
    }

}

void GameMessageUI::TextAnim(void)
{
    static constexpr float ChangeSpeedIN = 0.02f;
    static constexpr float ChangeSpeedOut = 0.04f;
    static constexpr float StayTimeSeconds = 2.0f; // DeltaTime(�b)�ɍ��킹�邽�ߌ^�Ɗ��ύX

    switch (animPhase_)
    {
    case GameMessageUI::ANIM_PHASE::FADE_IN:
        scaleX_ += ChangeSpeedIN;
        scaleY_ += ChangeSpeedIN;

        if (scaleX_ >= 1.0f)
        {
            scaleX_ = 1.0f;
            scaleY_ = 1.0f;
            animTime_ = 0.0f;
            animPhase_ = ANIM_PHASE::STAY;
        }
        break;
    case GameMessageUI::ANIM_PHASE::STAY:
        if (animTime_ >= StayTimeSeconds)
        {
            animPhase_ = ANIM_PHASE::FADE_OUT;
        }
        break;
    case GameMessageUI::ANIM_PHASE::FADE_OUT:
        scaleX_ -= ChangeSpeedOut;
        scaleY_ -= ChangeSpeedOut;

        if (scaleX_ <= 0.0f)
        {
            scaleX_ = 0.0f;
            scaleY_ = 0.0f;
            if (currentState_ == MASSAGE_STATE::EXPLAIN)
            {
                SetMassageState(MASSAGE_STATE::START);
                return;
            }
            SetMassageState(MASSAGE_STATE::NONE);
        }
        break;
    }
}

