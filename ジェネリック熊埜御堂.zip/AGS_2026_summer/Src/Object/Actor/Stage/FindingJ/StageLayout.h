#pragma once
#include<array>
#include<DxLib.h>

enum class StageLayout
{
    None = 0,
    Block,
    ReactionBlock,
};

constexpr StageLayout b = StageLayout::Block;
constexpr StageLayout n = StageLayout::None;
constexpr StageLayout r = StageLayout::ReactionBlock;

constexpr int TileSize = 20;
constexpr int W = 19;
constexpr int D = 11;
constexpr int H = 2;

namespace Stage1
{
    // �e�������Ƃ�D�sW���2�����z���H�p��
    constexpr std::array<std::array<std::array<StageLayout, W>, D>, H> stage = { {
        { // ===== ���� 0 =====
            {
                {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
                {b,b,b,b,b,b,b,b,r,b,r,b,b,b,b,b,b,b,b,},
                {b,b,b,b,b,r,b,b,b,b,b,b,b,r,b,b,b,b,b,},
                {b,b,b,r,b,b,b,b,r,b,r,b,b,b,b,r,b,b,b,},
                {b,r,b,b,b,b,b,r,b,b,b,r,b,b,b,b,b,r,b,},
                {b,b,b,b,r,b,b,b,b,r,b,b,b,b,b,b,b,b,b,},
                {b,r,b,b,b,b,b,r,b,b,b,r,b,b,b,b,b,r,b,},
                {b,b,b,r,b,b,b,b,r,b,r,b,b,b,b,r,b,b,b,},
                {b,b,b,b,b,r,b,b,b,b,b,b,b,r,b,b,b,b,b,},
                {b,b,b,b,b,b,b,b,r,b,r,b,b,b,b,b,b,b,b,},
                {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,}
            }
        },
        { // ===== ���� 1 =====
            {
                {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
                {b,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,b,},
                {b,n,b,b,b,n,b,b,b,n,b,b,b,n,b,b,b,n,b,},
                {b,n,n,n,b,n,b,n,n,n,n,n,b,n,b,n,n,n,b,},
                {b,n,b,n,b,n,b,n,b,n,b,n,b,n,b,n,b,n,b,},
                {b,n,b,n,n,n,n,n,n,n,n,n,n,n,n,n,b,n,b,},
                {b,n,b,n,b,n,b,n,b,n,b,n,b,n,b,n,b,n,b,},
                {b,n,n,n,b,n,b,n,n,n,n,n,b,n,b,n,n,n,b,},
                {b,n,b,b,b,n,b,b,b,n,b,b,b,n,b,b,b,n,b,},
                {b,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,b,},
                {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,}
            }
        }
    } };
}

namespace Stage2
{
    // �e�������Ƃ�D�sW���2�����z���H�p��
    constexpr std::array<std::array<std::array<StageLayout, W>, D>, H> stage = { {
         { // ===== ���� 0 =====
     {
         {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
         {b,r,b,b,b,b,b,b,b,r,b,b,b,b,b,b,b,r,b,},
         {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
         {b,b,b,b,b,b,b,r,b,b,b,r,b,b,b,b,b,b,b,},
         {b,b,b,b,b,b,b,b,r,b,r,b,b,b,b,b,b,b,b,},
         {b,r,b,b,b,b,r,b,b,b,b,b,r,b,b,b,b,r,b,},
         {b,b,b,b,b,b,b,b,r,b,r,b,b,b,b,b,b,b,b,},
         {b,b,b,b,b,b,b,r,b,b,b,r,b,b,b,b,b,b,b,},
         {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
         {b,r,b,b,b,b,b,b,b,r,b,b,b,b,b,b,b,r,b,},
         {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,}
     }
 },
 { // ===== ���� 1 =====
     {
         {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
         {b,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,b,},
         {b,n,b,b,b,b,b,b,n,b,n,b,b,b,b,b,b,n,b,},
         {b,n,n,n,n,n,n,n,n,b,n,n,n,n,n,n,n,n,b,},
         {b,n,b,b,b,b,n,b,n,n,n,b,n,b,b,b,b,n,b,},
         {b,n,n,n,n,n,n,b,n,b,n,b,n,n,n,n,n,n,b,},
         {b,n,b,b,b,b,n,b,n,n,n,b,n,b,b,b,b,n,b,},
         {b,n,n,n,n,n,n,n,n,b,n,n,n,n,n,n,n,n,b,},
         {b,n,b,b,b,b,b,b,n,b,n,b,b,b,b,b,b,n,b,},
         {b,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,b,},
         {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,}
     }
 }
    } };
}

namespace Stage3
{
    // �e�������Ƃ�D�sW���2�����z���H�p��
    constexpr std::array<std::array<std::array<StageLayout, W>, D>, H> stage = { {
       { // ===== ���� 0 =====
    {
       {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
        {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
        {b,b,b,b,b,r,b,b,r,b,r,b,b,r,b,b,b,b,b,},
        {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
        {b,b,r,b,b,b,b,r,b,b,b,r,b,b,b,b,r,b,b,},
        {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
        {b,b,r,b,b,b,b,r,b,b,b,r,b,b,b,b,r,b,b,},
        {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
        {b,b,b,b,b,r,b,b,r,b,r,b,b,r,b,b,b,b,b,},
        {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
        {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,}
    }
},
{ // ===== ���� 1 =====
    {
        {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,},
        {b,n,n,n,n,n,n,n,b,b,b,n,n,n,n,n,n,n,b,},
        {b,n,b,n,b,n,b,n,n,n,n,n,b,n,b,n,b,n,b,},
        {b,n,n,n,b,n,b,b,b,n,b,b,b,n,b,n,n,n,b,},
        {b,b,n,b,b,n,b,n,n,n,n,n,b,n,b,b,n,b,b,},
        {b,b,n,n,n,n,n,n,b,b,b,n,n,n,n,n,n,b,b,},
        {b,b,n,b,b,n,b,n,n,n,n,n,b,n,b,b,n,b,b,},
        {b,n,n,n,b,n,b,b,b,n,b,b,b,n,b,n,n,n,b,},
        {b,n,b,n,b,n,b,n,n,n,n,n,b,n,b,n,b,n,b,},
        {b,n,n,n,n,n,n,n,b,b,b,n,n,n,n,n,n,n,b,},
        {b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,}
    }
}
    } };

}