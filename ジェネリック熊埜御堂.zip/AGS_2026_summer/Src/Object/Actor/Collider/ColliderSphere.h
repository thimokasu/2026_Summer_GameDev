#pragma once
#include "ColliderBase.h"
class ColliderSphere :
    public ColliderBase
{
    public:
    //�R���X�g���N�^
    ColliderSphere(ColliderInfo& info, float radius, ActorBase& actor);
    ColliderSphere(ColliderInfo& info, float radius, ActorBase& actor, int debugColor);
    //���a�擾
    float GetRadius(void)const { return radius_; }
    //���a�ݒ�
	void SetRadius(float radius) { radius_ = radius; }

private:
	float radius_;
	void DrawDebug(int color) override;
};

