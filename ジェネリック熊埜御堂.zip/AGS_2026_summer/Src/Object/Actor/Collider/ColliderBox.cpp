#include "ColliderBox.h"

ColliderBox::ColliderBox(ColliderInfo& info, VECTOR& halfSize, ActorBase& actor)
    : ColliderBase(info, actor), halfSize_(halfSize)
{
}

ColliderBox::ColliderBox(ColliderInfo& info, VECTOR& halfSize, ActorBase& actor, int debugColor)
    : ColliderBase(info, actor), halfSize_(halfSize)
{
    info.debugColor_ = debugColor;
}

VECTOR ColliderBox::Local2World(const VECTOR& localPos) const
{
	VECTOR center = GetRotPos(colliderInfo_.localPos_);

	return VAdd(
		center,
		VAdd(
			VAdd(
				VScale(GetAxisX(), localPos.x),
				VScale(GetAxisY(), localPos.y)),
			VScale(GetAxisZ(), localPos.z)
		)
	);
}

VECTOR ColliderBox::World2Local(const VECTOR& worldPos) const
{
	// ���[���h���W���璆�S���W�������āA���[�J�����ɓ��e����
	VECTOR center = GetRotPos(colliderInfo_.localPos_);
	// ���[���h���W���璆�S���W������
	VECTOR dir = VSub(worldPos, center);
	// ���[�J�����ɓ��e����
	return VGet(
		VDot(dir, GetAxisX()),
		VDot(dir, GetAxisY()),
		VDot(dir, GetAxisZ())
	);
}

VECTOR ColliderBox::GetVertexPos(int index) const
{

	// ���S���W
	VECTOR center = GetRotPos(colliderInfo_.localPos_);

	// ���[���h��
	VECTOR axisX = GetOwnerTransform().GetRight();
	VECTOR axisY = GetOwnerTransform().GetUp();
	VECTOR axisZ = GetOwnerTransform().GetForward();

	// 8���_�̔z��
	VECTOR hx = VScale(axisX, halfSize_.x);
	VECTOR hy = VScale(axisY, halfSize_.y);
	VECTOR hz = VScale(axisZ, halfSize_.z);

	VECTOR v[8] =
	{
		VAdd(center,VAdd(VAdd(hx,hy),hz)),              // +x,+y,+z
		VAdd(center,VAdd(VAdd(hx,hy),VScale(hz,-1))),   // +x,+y,-z
		VAdd(center,VAdd(VAdd(hx,VScale(hy,-1)),hz)),   // +x,-y,+z
		VAdd(center,VAdd(VAdd(hx,VScale(hy,-1)),VScale(hz,-1))), // +x,-y,-z
		VAdd(center,VAdd(VAdd(VScale(hx,-1),hy),hz)),  // -x,+y,+z
		VAdd(center,VAdd(VAdd(VScale(hx,-1),hy),VScale(hz,-1))), // -x,+y,-z
		VAdd(center,VAdd(VAdd(VScale(hx,-1),VScale(hy,-1)),hz)), // -x,-y,+z
		VAdd(center,VAdd(VAdd(VScale(hx,-1),VScale(hy,-1)),VScale(hz,-1))) // -x,-y,-z
	};

	if (index < 0 || index > 7) return center; // �͈͊O�Ȃ璆�S�Ԃ�
	return v[index];
}

void ColliderBox::DrawDebug(int color)
{
	//���S���W
	VECTOR center = GetRotPos(colliderInfo_.localPos_);
	//���[���h��
	VECTOR axisX = GetOwnerTransform().GetRight();
	VECTOR axisY = GetOwnerTransform().GetUp();
	VECTOR axisZ = GetOwnerTransform().GetForward();
	//���S���璸�_�܂ł̃x�N�g��
	VECTOR hx = VScale(axisX, halfSize_.x);
	VECTOR hy = VScale(axisY, halfSize_.y);
	VECTOR hz = VScale(axisZ, halfSize_.z);
	// ���_���W�v�Z
	VECTOR v[8] =
	{
		VAdd(center,VAdd(VAdd(hx,hy),hz)),	// +x,+y,+z
		VAdd(center,VAdd(VAdd(hx,hy),VScale(hz,-1.0f))),	// +x,+y,-z
		VAdd(center,VAdd(VAdd(hx,VScale(hy,-1.0f)),hz)),	// +x,-y,+z
		VAdd(center,VAdd(VAdd(hx,VScale(hy,-1.0f)),VScale(hz,-1.0f))),	// +x,-y,-z
		VAdd(center,VAdd(VAdd(VScale(hx,-1.0f),hy),hz)),	// -x,+y,+z
		VAdd(center,VAdd(VAdd(VScale(hx,-1.0f),hy),VScale(hz,-1.0f))),	// -x,+y,-z
		VAdd(center,VAdd(VAdd(VScale(hx,-1.0f),VScale(hy,-1.0f)),hz)),	// -x,-y,+z
		VAdd(center,VAdd(VAdd(VScale(hx,-1.0f),VScale(hy,-1.0f)),VScale(hz,-1.0f)))	// -x,-y,-z
	};
	//12�ӂ̕`��
	unsigned char edges[12][2] =
	{
		{0,1},{0,2},{0,4},	// 0����1,2,4��
		{1,3},{1,5},		// 1����3,5��
		{2,3},{2,6},		// 2����3,6��
		{3,7},				// 3����7��
		{4,5},{4,6},		// 4����5,6��
		{5,7},				// 5����7��
		{6,7}				// 6����7��
	};
	for (int i = 0; i < 12; i++)
	{
		DrawLine3D(v[edges[i][0]], v[edges[i][1]], color);
	}

	DrawCube3D({ center.x - halfSize_.x,center.y - halfSize_.y,center.z - halfSize_.z },
		{ center.x + halfSize_.x,center.y + halfSize_.y,center.z + halfSize_.z },
		color, color, true);
	//���S�_
	DrawSphere3D(center, 2.0f, 8, color, color, false);

}
