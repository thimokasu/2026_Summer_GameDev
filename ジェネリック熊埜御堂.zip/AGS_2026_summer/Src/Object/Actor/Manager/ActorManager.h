#pragma once
#include <cstdint>
#include<vector>
#include<memory>
#include<unordered_map>
#include"../ActorBase.h"
#include"../EntityKind.h"
#include"../../../Scene/GameSelect/GameInfo.h"

using EntityID = uint32_t;
class ActorFactoryBase;

class ActorManager
{
public:
	ActorManager(void);
	~ActorManager(void);

	void Load(GameInfo info);
	void Init(void);
	void Update(void);
	void Draw(void);
	void Release(void);

	std::vector<std::unique_ptr<ActorBase>>& GetActors(void) { return actors_; }
	EntityKind GetEntityKind(EntityID id) const;
	//�w�肳�ꂽKind��Actor��Ԃ�
	std::vector<ActorBase*>FindActorsByKind(EntityKind kind)const;
	//�w�肳�ꂽID��Actor��Ԃ�
	ActorBase* FindActorByID(EntityID id) const;
private:
#pragma region �ϐ�
	std::vector<std::unique_ptr<ActorBase>> actors_;//�A�N�^�[�̃��X�g
	std::unordered_map<EntityID, EntityKind>id2kind_;//�G���e�B�e�BID����G���e�B�e�B��ʂւ̃}�b�v
	std::unique_ptr<ActorFactoryBase>actorFactory_;//�A�N�^�[�t�@�N�g���[
	int entityID_ = 0;
#pragma endregion
#pragma region �֐�
	void BindID2Kind(void);
	void SetFactory(GameInfo info);
	void OnePlayerGameFactory(GameInfo info);
	void TwoPlayerGameFactory(GameInfo info);
	void ThreePlayerGameFactory(GameInfo info);
	void FourPlayerGameFactory(GameInfo info);
#pragma endregion

};

