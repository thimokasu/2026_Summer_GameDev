#pragma once


enum class EntityKind
{
	//����
	NONE = 0,
	CAMERA,
	STAGE,
	PLAYER,

	//FindingJ
	BLOCK,
	REACTION_BLOCK,
	FINDINGJ_CPU
};