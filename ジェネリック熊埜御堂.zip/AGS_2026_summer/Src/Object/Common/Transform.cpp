#include "../../Utility/AsoUtility.h"
#include "Transform.h"

Transform::Transform(void)
{
    modelId = -1;

    scl = AsoUtility::VECTOR_ONE;
    rot = AsoUtility::VECTOR_ZERO;
    pos = AsoUtility::VECTOR_ZERO;
    localPos = AsoUtility::VECTOR_ZERO;

    matScl = MGetIdent();
    matRot = MGetIdent();
    matPos = MGetIdent();
}
Transform::Transform(int model)
{
    modelId = -1;

    scl = AsoUtility::VECTOR_ONE;
    rot = AsoUtility::VECTOR_ZERO;
    pos = AsoUtility::VECTOR_ZERO;
    localPos = AsoUtility::VECTOR_ZERO;

    matScl = MGetIdent();
    matRot = MGetIdent();
    matPos = MGetIdent();
}


Transform::~Transform(void)
{
}

void Transform::Update(void)
{
    // �傫��
    matScl = MGetScale(scl);

    // ��]
    rot = quaRot.ToEuler();
    matRot = quaRot.ToMatrix();

    // �ʒu
    matPos = MGetTranslate(pos);

    // �s��̍���
    MATRIX mat = MGetIdent();
    Quaternion q = quaRot.Mult(quaRotLocal);
    mat = MMult(mat, q.ToMatrix());
	mat = MMult(mat, matScl);
    mat = MMult(mat, matPos);

    // �s������f���ɔ���
    if (modelId != -1)
    {
        MV1SetMatrix(modelId, mat);
    }
}

void Transform::Release(void)
{
}

void Transform::SetModel(int model)
{
    modelId = model;
}

VECTOR Transform::GetForward(void) const
{
    return GetDir(AsoUtility::DIR_F);
}

VECTOR Transform::GetBack(void) const
{
    return GetDir(AsoUtility::DIR_B);
}

VECTOR Transform::GetRight(void) const
{
    return GetDir(AsoUtility::DIR_R);
}

VECTOR Transform::GetLeft(void) const
{
    return GetDir(AsoUtility::DIR_L);
}

VECTOR Transform::GetUp(void) const
{
    return GetDir(AsoUtility::DIR_U);
}

VECTOR Transform::GetDown(void) const
{
    return GetDir(AsoUtility::DIR_D);
}

VECTOR Transform::GetDir(const VECTOR& vec) const
{
    return quaRot.PosAxis(vec);
}
