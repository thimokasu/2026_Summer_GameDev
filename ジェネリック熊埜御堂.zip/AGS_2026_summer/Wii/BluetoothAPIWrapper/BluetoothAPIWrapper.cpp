// This is the main DLL file.

#include "stdafx.h"

#include "BluetoothAPIWrapper.h"

